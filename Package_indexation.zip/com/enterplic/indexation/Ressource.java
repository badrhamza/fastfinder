/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.enterplic.indexation;

import java.util.ArrayList;

/**
 *
 * @author Badr Hamza
 */
public class Ressource {
    
    private String name = "";
    private int type = 0;
    private String jHash = "";
    private int size = 0;
    private ArrayList<String> tags;
    
    public Ressource(String name, int type, int size, String jHash, ArrayList<String> tags) {
        this.name = name;
        this.type = type;
        this.size = size;
        this.jHash = jHash;
        this.tags = tags;
    }
    
    public Ressource() {
        
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }

    public String getjHash() {
        return jHash;
    }

    public void setjHash(String jHash) {
        this.jHash = jHash;
    }

    public int getSize() {
        return size;
    }

    public void setSize(int size) {
        this.size = size;
    }

    public ArrayList<String> getTags() {
        return tags;
    }

    public void setTags(ArrayList<String> tags) {
        this.tags = tags;
    }
    
    @Override
    public String toString() {
        return "Ressource{" + "name=" + name + ", type=" + type + ", jHash=" + jHash + ", size=" + size + ", tags=" + tags + '}';
    }
    
    
}
