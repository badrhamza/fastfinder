/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.enterplic.indexation.search;

import java.util.HashMap;

/**
 *
 * @author Badr Hamza
 */
public class SearchRequest {
    
    public static final int NAME_CRITERIA = 0;
    public static final int TYPE_CRITERIA = 1;
    public static final int TAGS_CRITERIA = 2;
    public static final int LOCATION_CRITERIA = 3;
    
    private HashMap<Integer, String> criteria;
    
    {
        for (int i =0; i< 4; i++) {
            this.criteria.put(i, "");
        }
    }
    
    public SearchRequest() {
        
    }
    
    public void addCriteria(int criteria, String value) {
        this.criteria.put(criteria, value);
    }
    
    public void removeCriteria(int criteria) {
        this.criteria.put(criteria, "");
    }
    
    public void clear() {
        for (int i =0; i< 4; i++) {
            this.criteria.put(i, "");
        }
    }
    
    public String getCriteria(int c) {
        return this.criteria.get(c);
    }
    
    /**
     *
     * @return
     */
    public String[] getAllCriterias() {
        String[] c = new String[4];
        
        for (int cs = 0; cs < criteria.size(); cs++) {
            c[cs] = this.getCriteria(cs);
        }
        return c;
    }
    
}
