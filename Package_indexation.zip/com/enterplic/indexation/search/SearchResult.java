/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.enterplic.indexation.search;

import java.util.ArrayList;

/**
 *
 * @author Badr Hamza
 */
public class SearchResult {
    private ArrayList<Integer> filesKey;
    
    public void addResult(int fileKey) {
        
    }
    
    public int getResultsCount() {
        return filesKey.size();
    }
    
    public int getFileKey(int i) {
        return filesKey.get(i);
    }
    
    public void clearResults() {
        filesKey.clear();
    }
}
