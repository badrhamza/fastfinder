/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.enterplic.indexation.browse;

import com.enterplic.indexation.IndexTable;
import java.io.IOException;

/**
 *
 * @author Badr Hamza
 */
public class BrowserProdConsMonitor {
    private IndexTable filesList = new IndexTable();
    private int maxSize;
    private boolean isPaused = false;
    private long filesCount = 0;
    private boolean terminated = false;
    
    public BrowserProdConsMonitor() {
        this.maxSize = 0;
    }
    
    public BrowserProdConsMonitor(int maxSize) {
        this.maxSize = maxSize;
    }
    
    public boolean isTerminated() {
        return this.terminated;
    }
    
    public void teminate() {
        this.terminated = true;
    }
    
    public void setSize(int size) {
        this.maxSize = size;
    }
    
    public long getFilesCount() {
        return this.filesCount;
    }
    
    public int size() {
        return filesList.size();
    }
    
    public synchronized void add(String path) throws IOException {
        if (size() == maxSize) {
            notify(); // notifier le thread indexeur
            try {
                wait(); // se mettre en attente
            } catch (InterruptedException ex) { }
        }
        filesList.add(path);
        this.filesCount++;
    }
    
    public synchronized IndexTable index() {
        if (size() < maxSize) {
            notify();
            try {
                wait();
            } catch (InterruptedException ex) {}
        }
        IndexTable newIt = null;
        newIt = filesList.clone();
        filesList.clear();
        return newIt;
    }

    public void setPauseStat(boolean stat) {
        this.isPaused = stat;
    }

    public boolean getPauseStat() {
        return this.isPaused;
    }
}
