/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.enterplic.indexation.browse;

import com.enterplic.indexation.IndexTable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.function.Function;

/**
 *
 * @author Badr Hamza
 */
public class Browser {
    
    private ArrayList<String> roots;
    private int RessourceBlockSize = 0;
    private String[] ignoredPaths;
    private BrowserProdConsMonitor oneBrowserMonitor; // Notre moniteur
    private BrowserThreadProd browserProd;
    private BrowserThreadCons browserCons;
    
    public Browser() {
        roots = new ArrayList();
    }
    
    public void add(String path) {
        roots.add(path);
    }
    
    public void addAll(Collection path) {
        roots.addAll(path);
    }
    
    public void clearRootsList() {
        roots.clear();
    }
    
    public void ignore(String[] paths) {
        ignoredPaths = paths;
    }
    
    public void setIntervalleSize(int size) {
        RessourceBlockSize = size;
    }
    
    public void pauseBrowsing() {
        oneBrowserMonitor.setPauseStat(true);
    }
    
    public void continueBrowsing() {
        oneBrowserMonitor.setPauseStat(false);
    }
    
    public void breakBrowsing() {
        oneBrowserMonitor.teminate();
        browserProd = null;
        browserCons = null;
    }
    
    public boolean isPaused() {
        return oneBrowserMonitor.getPauseStat();
    }
    
    public void startBrowsing(Function<IndexTable, Integer> poster_call, Function<Long, Integer> progress_call) throws DirectoriesListEmpty {
        if (roots.isEmpty()) throw new DirectoriesListEmpty();
        
        oneBrowserMonitor = new BrowserProdConsMonitor(this.RessourceBlockSize);
        /* Créer deux threads : le premier parcours les dossiers et rassemble 
        les fichiers collectés dans des blocks de tailles fixes, et 
        le deuxième les envoie à l'index */
        browserProd = new BrowserThreadProd(oneBrowserMonitor);
        browserCons = new BrowserThreadCons(oneBrowserMonitor, poster_call);
        browserProd.setRoots(roots);
        browserProd.ignore(ignoredPaths);
        /* Commencer le traitement */
        browserProd.start();
        browserCons.start();
        
        /* Créer un troisième thread qui renvoie la progression actuelle */
        new Thread() {
            @Override
            public void run() {
                while (!oneBrowserMonitor.isTerminated()) {
                    if (!oneBrowserMonitor.getPauseStat())
                        progress_call.apply(oneBrowserMonitor.getFilesCount());
                    try {
                        Thread.sleep(50);
                    } catch (InterruptedException ex) { }
                }
            }
        }.start();
    }
    
}
