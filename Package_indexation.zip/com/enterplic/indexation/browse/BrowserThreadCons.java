/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.enterplic.indexation.browse;

import com.enterplic.indexation.IndexTable;
import java.util.function.Function;

/**
 * Thread de consommation permettant de récupérer la table d'index produite par
 * le thread producteur
 * 
 * @author Badr Hamza
 * @version 1.0
 */
public final class BrowserThreadCons extends Thread {
    
    BrowserProdConsMonitor browserMonitor; // Reference to an BrowserProdConsMonitor object
    Function poster;
    
    public BrowserThreadCons() {
        
    }
    
    /**
     * Instancier un nouveau Thread de consommation
     * @param Brws
     *  Spécifie le moniteur de ressources
     */
    public BrowserThreadCons(BrowserProdConsMonitor Brws) {
        this.browserMonitor = Brws;
    }
    
    /**
     * Instancier un nouveau Thread de consommation
     * @param Brws
     *  Spécifie le moniteur de ressources
     * @param poster_call
     *  Spécifie la fonction à appeler après une demande d'indexation
     */
    public BrowserThreadCons(BrowserProdConsMonitor Brws, Function<IndexTable, Integer> poster_call) {
        this.browserMonitor = Brws;
        setPoster(poster_call);
    }
    
    /**
     * Passer en paramètre le moniteur partagé
     * @param Brws
     *  Un objet moniteur de ressources
     */
    public void setMonitor(BrowserProdConsMonitor Brws) {
        browserMonitor = Brws;
    }
    
    /**
     * Appeler une fonction poster_call après chaque demande d'indexation
     * @param poster_call
     *   Spécifie la fonction à appeler
     */
    public void setPoster(Function<IndexTable, Integer> poster_call) {
        this.poster = poster_call;
    }
    
    @Override
    public void run() {
        IndexTable it;
        while (!this.browserMonitor.isTerminated()) {
            /* On consomme la ressource */
            it = this.browserMonitor.index();
            /* Ici on poste sur le serveur le contenu récupéré depuis le disque */
            this.poster.apply(it.clone());
            it.clear();
        }
    }
}
