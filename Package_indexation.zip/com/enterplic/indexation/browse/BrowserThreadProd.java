/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.enterplic.indexation.browse;

import java.io.File;
import java.io.FileFilter;
import java.io.IOException;
import java.util.ArrayList;

/**
 * Thread de production permettant de parcourir les supports de stockage
 * 
 * @author Badr Hamza
 * @version 1.0
 */
public class BrowserThreadProd extends Thread {
    private BrowserProdConsMonitor browserMonitor; // Reference to an BrowserProdConsMonitor object
    private String[] ignoredPaths;
    private ArrayList<String> roots;
    
    public BrowserThreadProd() {
        
    }
    
    /**
     * Instancier un nouveau Thread de production
     * @param Brws
     *  Spécifie le moniteur de ressources
     */
    public BrowserThreadProd(BrowserProdConsMonitor Brws) {
        browserMonitor = Brws;
    }

    /**
     * Passer en paramètre le moniteur partagé
     * @param Brws
     *  Un objet moniteur de ressources
     */
    public void setMonitor(BrowserProdConsMonitor Brws) {
        browserMonitor = Brws;
    }
    
    /**
     * Fixe la liste des racines des supports de stockage à indexer
     * @param roots
     */
    public void setRoots(ArrayList<String> roots) {
        this.roots = roots;
    }

    /**
     * Fixe la liste des répertoires à omettre du processus d'indexation
     * @param paths
     */
    public void ignore(String[] paths) {
        this.ignoredPaths = paths;
    }

    private File[] getDirectories(String path) {
        File dir = new File(path);
        FileFilter fileFilter = File::isDirectory;
        return dir.listFiles(fileFilter);
    }

    private File[] getFiles(String path) {
        File dir = new File(path);
        FileFilter fileFilter = File::isFile;
        return dir.listFiles(fileFilter);
    }

    private void browse(String path) throws IOException {
        for (String s:this.ignoredPaths)
            if (s.equals(path))
                return;
        System.out.println(path);
        File[] dirs = getDirectories(path);
        File[] files = getFiles(path);
        
        if (this.browserMonitor.isTerminated()) {
            this.interrupt();
        }
        
        while (this.browserMonitor.getPauseStat())
            try {
                Thread.sleep(10);
            } catch (InterruptedException ex) { }
        
        if (files != null && files.length != 0) {
            for (File f : files) {
                this.browserMonitor.add(f.getPath());
            }
        }
        
        if (dirs != null && dirs.length != 0) {
            for (File d : dirs)
                browse(d.getPath());
        }
    }

    @Override
    public void run() {
        for (String root : roots) {
            try {
                browse(root);
            } catch (IOException ex) {
                ex.printStackTrace();
            }
        }
        this.browserMonitor.teminate();
    }
}
