/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.enterplic.indexation;

import com.enterplic.indexation.search.SearchResult;
import com.enterplic.indexation.search.SearchRequest;

/**
 *
 * @author Badr Hamza
 */
public class FileSynch {
    
    private int userID;
    
    public FileSynch() {
        
    }
    
    /**
     *
     * @param userName
     * @param password
     * @throws PlateformeConnectException
     * @throws UserLoginException
     */
    public void connect(String userName, String password) throws PlateformeConnectException, UserLoginException {
        
    }
    
    /**
     *
     * @param it
     * @return 
     * @throws PlateformeConnectException
     */
    public int post(IndexTable it) throws PlateformeConnectException {
        return 0;
    }
    
    /**
     *
     * @param fileKey
     * @return
     */
    public Ressource get(long fileKey) {
        return null;
    }
    
    /**
     *
     * @param sr
     * @param mode local (0), global (1) or both (2)
     * @return 
     * @throws com.enterplic.indexation.PlateformeConnectException 
     */
    public SearchResult find(SearchRequest sr, int mode) throws PlateformeConnectException {
        return null;
    }
    
    private void findLocal() {
        
    }
    
    private void findGlobal() {
        
    }
    
    /**
     *
     * @param name
     * @param password
     */
    public void addGroup(String name, String password) {
        
    }
    
    /**
     *
     * @param name
     */
    public void removeGroup(String name) {
        
    }
    
    public void addFilesToGroup(int[] filesKey, String group) {
        
    }
    
    public void removeFilesFromGroup(int[] filesKey, String group) {
        
    }
    
    public void clearGroup(String group) {
        
    }
}
