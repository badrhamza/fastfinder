
package com.enterplic.indexation;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Date;
import java.security.DigestInputStream;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;

/**
 * Représente la table d'index dans laquelle seront stockés des informations sur les fichiers indexables
 * 
 * @author Badr Hamza
 * @version 1.0
 */
public class IndexTable extends JSONArray {
    
    //private ArrayList<JSONObject> jsonFilesList = new ArrayList();
    
    public IndexTable() {
       
    }
    
    /**
     * Créer un nouveau objet IndexTable à partir d'un string jsonText
     * @param jsonText
     *  Un string de format JSON qui sera désérialisé vers un objet IndexTable
     * @throws ParseException Si jamais "jsonText" est mal formé
     */
    public IndexTable(String jsonText) throws ParseException {
        JSONParser parser = new JSONParser();
        addAll((ArrayList<JSONObject>) parser.parse(jsonText));
    }
    
    /**
     * Ajouter un nouveau fichier dans la table d'index désigné par son chemin absolu
     * @param path
     *  Spécifier le chemin d'un fichier existant
     * @throws IOException
     */
    public void add(String path) throws IOException {
        File newFile = new File(path);
        add(new JSONObject() {
            {
                put("name", newFile.getName());
                put("keywords", newFile.getName().replace(' ', ','));
                put("hashcode", computeHashCode(path));
                put("size", 100);
                System.out.println(newFile.getName());
                put("type", getExtension(newFile.getName()));
                put("keywords", newFile.getName().replace(' ', ','));
                put("location", newFile.getPath());
                put("device", "Badr-PC");
            }
        });
        
    }
    
    @Override
    public int size() {
        return super.size();
    }
    
    @Override
    public void clear() {
        super.clear();
    }
    
    /**
     * Convertit l'objet IndexTable en trame JSON
     * 
     * @return un text string représentant l'objet IndexTable au format JSON
     */
    public String getJsonFrame() {
        JSONObject jsonIndexTable = new JSONObject();
        
        jsonIndexTable.put("generator", "FastFind Application");
        jsonIndexTable.put("version", "1.0.0");
        jsonIndexTable.put("date", new Date().getTime());
        
        jsonIndexTable.put("list", this.clone());
        return jsonIndexTable.toJSONString();
    }
    
    private String getExtension(String fileName) {
        String ext = "";
        try {
            ext = fileName.substring(fileName.lastIndexOf(".") + 1);
        } catch (IndexOutOfBoundsException e) { }
        return ext;
    }
    
    private String computeHashCode(String path) throws IOException {
        MessageDigest md = null;
        String hash = "x";
        try {
            md = MessageDigest.getInstance("SHA-256");
        } catch (NoSuchAlgorithmException ex) { }
        
        try {
            // file hashing with DigestInputStream
            try (DigestInputStream dis = new DigestInputStream(new FileInputStream(path), md)) {
                while (dis.read() != -1); //empty loop to clear the data
                md = dis.getMessageDigest();
            }
            // bytes to hex
            StringBuilder result = new StringBuilder();
            for (byte b : md.digest()) {
                result.append(String.format("%02x", b));
            }
            hash = result.toString();
        } catch (FileNotFoundException e) { }
        return hash;
    }
    
    @Override
    public IndexTable clone() {
        /*IndexTable it = null;
        try {
            it = new IndexTable(this.toJSONString());
        } catch (ParseException ex) { }
        */
        return (IndexTable) super.clone();// it;
    }
}
